
#ifndef INDICATORS_FONT_STYLE
#define INDICATORS_FONT_STYLE

namespace indicators {
enum class FontStyle { bold, dark, italic, underline, blink, reverse, concealed, crossed };
}

#endif
